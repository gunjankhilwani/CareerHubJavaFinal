package com.careerhub.exception;

public class SalaryCalculationException extends Exception {

	public SalaryCalculationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SalaryCalculationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
