package com.careerhub.exception;

public class ApplicationDeadlineException extends Exception {

	public ApplicationDeadlineException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApplicationDeadlineException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
