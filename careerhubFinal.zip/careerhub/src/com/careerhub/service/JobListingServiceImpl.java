package com.careerhub.service;

import java.util.List;

import com.careerhub.dao.JobListingDaoImpl;
import com.careerhub.entity.Applicant;

public class JobListingServiceImpl implements IJobListingService {

	JobListingDaoImpl jbl=new JobListingDaoImpl();
	@Override
	public void apply() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getApplicant() {
		// TODO Auto-generated method stub
		List<Applicant> arr= jbl.getApplicants();
		for(Applicant ap:arr)
		{
			System.out.println(ap.toString());
		}
		
	}
	
}
