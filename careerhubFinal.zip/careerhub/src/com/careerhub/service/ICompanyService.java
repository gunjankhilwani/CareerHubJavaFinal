package com.careerhub.service;

import java.util.List;

import com.careerhub.entity.JobListing;


public interface ICompanyService {
	void getJobs();
	 
	void postJob(JobListing jb);

}
