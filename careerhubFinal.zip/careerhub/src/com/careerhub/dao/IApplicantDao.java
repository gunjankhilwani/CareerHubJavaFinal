package com.careerhub.dao;

import com.careerhub.entity.Applicant;
import com.careerhub.exception.ApplicationDeadlineException;
import com.careerhub.exception.InvalidEmailFormatException;

public interface IApplicantDao {
	
	void createProfile(Applicant Profile) throws InvalidEmailFormatException;
    void applyForJob(int jobID, String coverLetter)throws ApplicationDeadlineException;
}
