package com.careerhub.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.careerhub.entity.Applicant;
import com.careerhub.entity.Company;
import com.careerhub.entity.JobApplication;
import com.careerhub.entity.JobListing;
import com.careerhub.exception.FileUploadException;
import com.careerhub.util.DBUtil;
import com.mysql.cj.xdevapi.Statement;

public class DataManagerDaoImpl implements IDatabaseManagerDao {

	PreparedStatement preparedStatement;
	Statement statement;
	ResultSet resultSet;
	@Override
	public void initializeDatabase() {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertJobListing(JobListing job) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertCompany(Company company) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertApplicant(Applicant applicant) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insertJobApplication(JobApplication application) throws FileUploadException{
		//TRIED TODO Auto-generated method stub
		try {
			Connection connection = DBUtil.createConnection();
			
			preparedStatement = connection.prepareStatement("INSERT INTO JobApplication(ApplicationID,JobID,ApplicantID,ApplicationDate,CoverLetter) VALUES (?,?,?,?,?)");
			preparedStatement.setInt(1,application.getApplicationID());
			preparedStatement.setInt(2,application.getJobID());
			preparedStatement.setInt(3,application.getApplicantID());
			preparedStatement.setDate(4,Date.valueOf(application.getApplicationDate()));
			
			if(application.getCoverLetter().length()<500)
			{
				preparedStatement.setString(5,application.getCoverLetter());
			}
			else {
				throw new FileUploadException("Your cover letter is exceding the valid length ");
			}
			
			int row= preparedStatement.executeUpdate();
			if(row==1)
			{
				System.out.println("Done Done");
			}
			else {
				System.out.println("Not Done");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

		

	}

	@Override
	public List<JobListing> getJobListings() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Company> getCompanies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Applicant> getApplicants() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<JobApplication> getApplicationsForJob(int jobID) {
		// TODO Auto-generated method stub
		return null;
	}

}
