package com.careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.List;

import com.careerhub.entity.JobListing;
import com.careerhub.util.DBUtil;
import com.mysql.cj.xdevapi.Statement;

public class CompanyDaoImpl implements ICompanyDao {

	PreparedStatement preparedStatement;
	Statement statement;
	ResultSet resultSet;

	@Override
	public void postJob(JobListing jb) {
		try {
			Connection connection = DBUtil.createConnection();
			
			preparedStatement = connection.prepareStatement("INSERT INTO JobListing(CompanyID,JobTitle,JobDescription,JobLocation,Salary,JobType,PostedDate) VALUES (?,?,?,?,?,?,?)");
			preparedStatement.setInt(1,jb.getCompany().getCompanyID());
			preparedStatement.setString(2,jb.getJobTitle());
			preparedStatement.setString(3,jb.getJobDescription());
			preparedStatement.setString(4,jb.getJobLocation());
			preparedStatement.setFloat(5,jb.getSalary());
			preparedStatement.setString(6,jb.getJobType());
			preparedStatement.setDate(7,Date.valueOf(jb.getPostedDate()));

			int row= preparedStatement.executeUpdate();
			if(row==1)
			{
				System.out.println("Done Done");
			}
			else {
				System.out.println("Not Done");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
      
		DBUtil.closeConnection();
	
	}
//	@Override
//	public List<JobListing> getjobs() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	@Override
//	public void postJob(String jobTitle, String jobDescription, String jobLocation, float salary, String jobType) {
//		// TODO Auto-generated method stub
//		
//	}

	//@Override
//	public void postJob(String jobTitle, String jobDescription, String jobLocation, double salary, String jobType) {
//		// TODO Auto-generated method stub
//		
//	}

	@Override
	public List<JobListing> getJobs() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void postJob(String jobTitle, String jobDescription, String jobLocation, double salary, String jobType) {
		// TODO Auto-generated method stub
		
	}

	


}
